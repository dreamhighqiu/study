//var win = window;var count = 0;document.body.innerHTML = (win.location.href + '-11-' + count);while(win.location.href=='about:blank'){count++;win = window.parent.window;document.body.innerHTML = (win.location.href + '--' + count);}
var win = window;

var urlSplitArray = '';
var baseUrlFolder = '';
var baseUrl = '';

var localBase64Loader = {

	hasInit:false,
	init:function(){
		var win = window;
		win = window;
		console.log(win.location.href);
		if(win.location.href == 'about:blank'){
			baseUrl = 'about:/';
		}else{
			urlSplitArray = win.location.href.split('/');
			urlSplitArray.pop();
			baseUrlFolder = '/'+urlSplitArray[urlSplitArray.length-1];
			baseUrl = urlSplitArray.join('/');
			if(baseUrl.indexOf('file:///')==0){ baseUrl=baseUrl.substr(8,baseUrl.length-1); }
		}
		this.hasInit = true;
	},
	chenckResource:function(url,callback){
		console.log(url)
		
		var url2 = url.split("/")
        var key = url2[url2.length - 1];
		var extension = key.split(".")[1];
		key = key.replace(".", "_");
		
		var item = assetsPackage[key];
		
		if(extension == "json" 
			|| extension == "atlas" 
			|| extension == "ani" 
			|| extension == "lh" 
			|| extension == "lav" 
			|| extension == "lmat" 
			|| extension == "ltc" 
			|| extension == "lang" 
		)
		{
			item = JSON.parse(item);
		}

		if(callback){
				callback(item);
		}else{
				return item;
		}
	},
	getResourceToByteArray:function(url,callback){
		console.log(url);

		var url2 = url.split("/")
        var key = url2[url2.length - 1];
		var extension = key.split(".")[1];
		key = key.replace(".", "_");
		
		var item = assetsPackage[key];
		
		if(extension == "json" 
			|| extension == "atlas" 
			|| extension == "ani" 
			|| extension == "lh" 
			|| extension == "lav" 
			|| extension == "lmat" 
			|| extension == "ltc" 
			|| extension == "lang" 
		)
		{
			item = JSON.parse(item);
		}
		
        var response = base64js.toByteArray(item);
        //console.log("load success: "+ relativeUrl);
        if(callback){
        	callback(response);
        }else{
        	return response;
        }
	},
	base64DataToByteArray:function(base64Data){
		//if(this.hasInit==false) this.init();
		return base64js.toByteArray(base64Data).buffer;
	}
}