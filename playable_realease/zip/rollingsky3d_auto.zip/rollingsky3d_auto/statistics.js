(function (i, s, o, g, r, a, m) {
  i['GoogleAnalyticsObject'] = r;
  i[r] = i[r] || function () {
    (i[r].q = i[r].q || []).push(arguments)
  }, i[r].l = 1 * new Date();
  a = s.createElement(o),
    m = s.getElementsByTagName(o)[0];
  a.async = 1;
  a.src = g;
  m.parentNode.insertBefore(a, m)
})(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');
ga('create', 'UA-110565682-1', 'auto');
ga('set', 'checkProtocolTask', null); // Disable file protocol checking.
ga('set', 'checkStorageTask', null); // Disable cookie storage checking.
ga('set', 'historyImportTask', null); // Disable history checking (requires reading from cookies).
ga('send', 'pageview'); // stat `pv`

//预加载发送GA
ga && ga('send', {
  title: document.title,
  hitType: 'event',
  eventCategory: 'playable_rollingsky3d',
  eventAction: 'playable_before_load',
  eventLabel: 'playable_rollingsky3d_before_show'
})

//加载完成发送GA
function winSendGaAfterLoadCompleted(){
  ga && ga('send', {
    title: document.title,
    hitType: 'event',
    eventCategory: 'playable_rollingsky3d',
    eventAction: 'playable_show',
    eventLabel: 'playable_rollingsky3d_showsuccess'
  })
}

//点击发送Ga
function winSendGaByClickAD(){

  function jumpFunc(){
    var flag = document.getElementById("mobvista_flag")
    var notice = flag.getAttribute("data-notice-url")
    window.location.href = notice
  }

  setTimeout(jumpFunc,1000)
  
  ga('send', {
    title: document.title,
    hitType: 'event',
    eventCategory: 'playable_rollingsky3d',
    eventAction: 'playable_rollingsky3d_click',
    eventLabel: 'playable_click_rollingsky3d_link',
    hitCallback: function(){
      jumpFunc()
    }
  });

  
}

//试玩发送Ga
function winTryPlayGame() {
  
  ga('send', {
    title: document.title,
    hitType: 'event',
    eventCategory: 'playable_rollingsky3d',
    eventAction: 'playable_rollingsky3d_try',
    eventLabel: 'playable_try_rollingsky3d_link'
  });

  var flag = document.getElementById("mv_play");
  var notice = flag.getAttribute("data-url");
  (new Image()).src = notice
}

window.addEventListener('load', function(){
  var els = document.getElementById('mv_stats');
  var arr = els.getAttribute('data-url').split('<#>');
  for (var i = 0;i<arr.length;i++){
    (new Image()).src = arr[i];
  }
  winSendGaAfterLoadCompleted()
})